
//Zahin Hossain

#include <stdio.h>
#define PI 3.14159265358979323846
double square(double base) { double sum; sum = base * base;  return sum; }
double sphere(double radius) { double sum; sum = PI * 4/3 * radius * radius * radius; return sum;};
double cube(double basec) { double sum; sum= basec*basec* 6; return sum; };

int menu() {
	int choice;
	
	do {
		printf("1) Compute the area of a square\n");
		printf("2) Compute the volume of a sphere\n");
		printf("3) Compute the surface area of a cube\n");
		printf("4) Quit\n");

		printf("Enter an option: ");
		scanf("%d", &choice);
		if (choice < 1 || choice > 4)  
		{
			printf("Incorrect input. Press any key to continue..");
			getch();
			printf("\n\n");
		}
	} while (choice < 1 || choice > 4);
	return choice;
}

void main(void)  
{
	int select = 0;
	double x, sum;

		select = menu();
		switch (select) 
		{
		case 1:
			printf("\nEnter the side length (cm) of the square: ");
			scanf("%lf",&x);
			sum = square(x);
			printf("Area of the square: %0.2lf (cm)\n\n", sum);
			menu();
		case 2:
			printf("\nEnter the radius of the sphere (cm): ");
			scanf("%lf", &x);
			sum = sphere(x);
			printf("Volume of the sphere: %0.2lf (cm)\n\n", sum);
			menu();
		case 3:
			printf("\nEnter the edge of the cube: ");
			scanf("%lf", &x);
			sum = cube(x);
			printf("Surface Area of cube: %0.2lf (cm)\n\n", sum);
			menu();
		case 4:
			printf("\nBye Bye for now!");
			return 0;
			break;
		}
	}



