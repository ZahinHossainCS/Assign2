//Zahin Hossain
#include <stdio.h>

int main() {
    float start,add,ret;
    int year,z;

      do{
        printf("Enter intital investment amount: ");
        scanf("%f", &start);
        if (start < 0)
        {
            printf("Intial Investment Cannot be negative. Please try again\n");
        }
      }
      while (start < 0);

      do{
          printf("Enter total years: ");
          scanf("%d", &year);
          if (year <= 0)
          {
              printf("Years Must be greater than zero. Please Try again.\n");
          }
      }
      while (year <= 0);

      do {
          printf("Enter return rate: ");
          scanf("%f", &ret);
          if (ret < 0)
          {
              printf("Rate cannot be negative. Please Try again.\n");
          }
      }
      while (ret < 0);
     
      do {
          printf("Enter additional contribution per year: ");
          scanf("%f", &add);
          if (add < 0)
          {
              printf("Contribution cannot be negative. Please Try again.\n");
          }
      }
      while (add < 0);

        ret = ret * 0.01;
        printf("\n\nYear      Start Balance       Interest            End Balance");
        printf("\n");
        printf("*************************************************************************");
        printf("\n");

        for (z = 1; z <= year; z++)
        {
            printf("%-10d%-20.2f", z, start);
            printf("%-20.2f%-20.2f",start * ret, start * (1 + ret));
            start = start * (1 + ret) + add;
            printf("\n");
        }
}